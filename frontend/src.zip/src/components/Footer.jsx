import { useState } from 'react'
import logoIcon from '../assets/logo-icon.svg'
const navLinks = ['About Us', 'Order Tracking', 'Exchange Orders', 'Contact Us']
const policyLinks = ['Disclaimer', 'Exchange Only', 'Terms & Conditions', 'Privacy Policy']
function SocialIcon({ children, label }) {
  return (
    <a
      href="#"
      aria-label={label}
      className="flex h-9 w-9 items-center justify-center rounded-full bg-brown-dark text-white transition-all duration-300 hover:bg-gold hover:text-brown-dark"
    >
      {children}
    </a>
  )
}
function Footer() {
  const [email, setEmail] = useState('')
  const handleSubmit = (e) => {
    e.preventDefault()
    setEmail('')
  }
  return (
    <footer className="bg-cream-light pt-16 pb-6">
      <div className="section-container">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-2 lg:grid-cols-4 lg:gap-8">
          {/* Brand column */}
          <div>
            <a href="/" className="flex items-center gap-2.5">
              <img src={logoIcon} alt="" className="h-8 w-8" />
              <span className="font-serif text-xl font-semibold text-brown">ShriTatvam</span>
            </a>
            <p className="mt-4 text-sm leading-relaxed text-brown-muted">
              Premium pooja essentials, exquisitely curated for a divine experience.
            </p>
            <div className="mt-5 flex gap-3">
              <SocialIcon label="Facebook">
                <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
              </SocialIcon>
              <SocialIcon label="Instagram">
                <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
              </SocialIcon>
              <SocialIcon label="YouTube">
                <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
              </SocialIcon>
              <SocialIcon label="Pinterest">
                <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0C5.373 0 0 5.372 0 12c0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.403.041-3.439.219-.937 1.406-5.957 1.406-5.957s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.688 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.063-4.869-5.008-4.869-3.41 0-5.409 2.562-5.409 5.199 0 1.033.394 2.143.889 2.741.099.12.112.225.085.345-.09.375-.293 1.199-.334 1.363-.053.225-.172.271-.401.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.92-7.252 4.158 0 7.392 2.967 7.392 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.357-.629-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24 12 24c6.627 0 12-5.373 12-12 0-6.628-5.373-12-12-12z"/></svg>
              </SocialIcon>
            </div>
            <div className="mt-6 space-y-2">
              <p className="text-xs font-semibold uppercase tracking-wider text-brown">Customer Support</p>
              <p className="text-sm text-brown-muted">
                <a href="tel:+919876543210" className="transition-colors hover:text-brown">+91 98765 43210</a>
                {' '}(WhatsApp)
              </p>
              <p className="text-sm text-brown-muted">
                <a href="mailto:support@shritattvam.com" className="transition-colors hover:text-brown">support@shritattvam.com</a>
              </p>
            </div>
          </div>
          {/* Navigation */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-brown">Navigation</h3>
            <ul className="mt-4 space-y-3">
              {navLinks.map((link) => (
                <li key={link}>
                  <a href={`#${link.toLowerCase().replace(/\s+/g, '-')}`} className="text-sm text-brown-muted transition-colors duration-300 hover:text-brown">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          {/* Policy */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-brown">Policy</h3>
            <ul className="mt-4 space-y-3">
              {policyLinks.map((link) => (
                <li key={link}>
                  <a href={`#${link.toLowerCase().replace(/\s+/g, '-')}`} className="text-sm text-brown-muted transition-colors duration-300 hover:text-brown">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          {/* Newsletter */}
          <div>
            <h3 className="font-serif text-lg font-medium text-brown">Let&apos;s Get in Touch</h3>
            <p className="mt-3 text-sm leading-relaxed text-brown-muted">
              Subscribe to receive updates on new collections, exclusive offers, and spiritual inspiration.
            </p>
            <form onSubmit={handleSubmit} className="mt-5">
              <div className="flex overflow-hidden rounded border border-brown/15">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Your email address"
                  required
                  className="flex-1 bg-white px-4 py-3 text-sm text-brown placeholder:text-brown-muted/50 outline-none"
                />
                <button type="submit" className="btn-dark shrink-0 rounded-none px-5">
                  Sign Up
                </button>
              </div>
              <p className="mt-2 text-[11px] text-brown-muted/70">
                By signing up, you agree to our Privacy Policy.
              </p>
            </form>
          </div>
        </div>
        {/* Bottom bar */}
        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-brown/10 pt-6 md:flex-row">
          <p className="text-xs text-brown-muted">
            © 2026 ShriTatvam. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <span className="text-xs text-brown-muted">Secure Checkout</span>
            <div className="flex items-center gap-2">
              {['Visa', 'MC', 'Amex', 'UPI', 'RuPay'].map((method) => (
                <span
                  key={method}
                  className="rounded border border-brown/10 bg-white px-2 py-1 text-[10px] font-medium text-brown-muted"
                >
                  {method}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
export default Footer