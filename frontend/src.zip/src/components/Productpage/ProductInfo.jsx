import React from "react";
import ProductFeatures from "./ProductFeatures";
import ProductActions from "./ProductActions";

const ProductInfo = () => {
  return (
    <div className="flex flex-col">
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="flex gap-0.5 text-[#c48421]">
          <span>★</span>
          <span>★</span>
          <span>★</span>
          <span>★</span>
          <span>★</span>
        </div>

        <span className="text-sm font-medium text-stone-700">4.8</span>
        <span className="text-sm text-stone-500">(101 reviews)</span>
      </div>

      <h1 className="font-serif text-3xl leading-tight text-stone-950 sm:text-4xl">
        Divine Pooja Kit (Small)
      </h1>

      <div className="mt-5 flex flex-wrap items-center gap-4">
        <span className="text-2xl font-semibold text-stone-950">
          ₹1,499
        </span>

        <span className="text-base text-stone-400 line-through">
          ₹1,999
        </span>

        <span className="rounded-md bg-[#f5eee3] px-3 py-1 text-xs font-semibold text-stone-700">
          25% OFF
        </span>
      </div>

      <p className="mt-5 max-w-xl text-sm leading-7 text-stone-700">
        A complete pooja kit with all essential items for daily prayers and
        rituals.
      </p>

      <div className="mt-5">
        <ProductFeatures />
      </div>

      <div className="mt-7">
        <ProductActions />
      </div>
    </div>
  );
};

export default ProductInfo;