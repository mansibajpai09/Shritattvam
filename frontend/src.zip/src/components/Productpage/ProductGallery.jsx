import React, { useMemo, useState } from "react";

const ProductGallery = () => {
  const images = useMemo(() => {
    const modules = import.meta.glob(
      "../../assets/productimg/*.{png,jpg,jpeg,webp,avif}",
      {
        eager: true,
        query: "?url",
        import: "default",
      }
    );

    return Object.values(modules);
  }, []);

  const fallbackImages = [
    "https://images.unsplash.com/photo-1604608672516-f1b9c4b0b9b3?auto=format&fit=crop&w=1200&q=80",
    "https://images.unsplash.com/photo-1545231027-637d2f6210f8?auto=format&fit=crop&w=1200&q=80",
    "https://images.unsplash.com/photo-1600880292089-90a7e086ee0c?auto=format&fit=crop&w=1200&q=80",
  ];

  const galleryImages = images.length ? images : fallbackImages;
  const [selectedImage, setSelectedImage] = useState(0);
  const [zoomOrigin, setZoomOrigin] = useState("50% 50%");
  const [isZoomed, setIsZoomed] = useState(false);

  const handleMouseMove = (event) => {
    const rect = event.currentTarget.getBoundingClientRect();

    const x = ((event.clientX - rect.left) / rect.width) * 100;
    const y = ((event.clientY - rect.top) / rect.height) * 100;

    setZoomOrigin(`${x}% ${y}%`);
  };

  return (
    <div className="w-full">
      <div className="overflow-hidden rounded-xl bg-[#f4eadc]">
        <div
          className="group relative aspect-square w-full cursor-zoom-in overflow-hidden"
          onMouseEnter={() => setIsZoomed(true)}
          onMouseLeave={() => setIsZoomed(false)}
          onMouseMove={handleMouseMove}
        >
          <img
            src={galleryImages[selectedImage]}
            alt="Divine Pooja Kit"
            className="h-full w-full object-cover transition-transform duration-200"
            style={{
              transform: isZoomed ? "scale(2)" : "scale(1)",
              transformOrigin: zoomOrigin,
            }}
          />

          <div className="pointer-events-none absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full bg-white/80 text-stone-700 opacity-0 shadow-sm backdrop-blur-sm transition-opacity duration-200 group-hover:opacity-100">
            +
          </div>
        </div>
      </div>

      <div className="mt-4 flex items-center justify-center gap-2">
        {galleryImages.slice(0, 5).map((image, index) => (
          <button
            key={`${image}-${index}`}
            type="button"
            onClick={() => setSelectedImage(index)}
            aria-label={`View product image ${index + 1}`}
            className={`h-2.5 w-2.5 rounded-full transition-all duration-300 ${
              selectedImage === index
                ? "scale-110 bg-[#b98535]"
                : "bg-stone-300 hover:bg-stone-400"
            }`}
          />
        ))}
      </div>
    </div>
  );
};

export default ProductGallery;