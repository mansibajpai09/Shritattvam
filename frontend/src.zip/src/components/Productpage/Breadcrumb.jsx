import React from "react";

const Breadcrumb = () => {
  return (
    <div className="flex flex-wrap items-center gap-2 text-sm text-stone-500 mb-6">
      <span className="hover:text-stone-900 cursor-pointer">Home</span>
      <span>/</span>
      <span className="hover:text-stone-900 cursor-pointer">Poojakit</span>
      <span>/</span>
      <span className="text-stone-900">Divine Pooja Kit (Small)</span>
    </div>
  );
};

export default Breadcrumb;