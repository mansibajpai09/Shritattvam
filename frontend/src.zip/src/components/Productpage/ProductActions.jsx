import React, { useState } from "react";
import QuantitySelector from "./QuantitySelector";

const ProductActions = () => {
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  const handleAddToCart = () => {
    setAdded(true);

    setTimeout(() => {
      setAdded(false);
    }, 1800);
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <span className="rounded-md bg-[#eef5e8] px-3 py-1.5 text-sm font-medium text-green-700">
          In Stock
        </span>
      </div>

      <QuantitySelector
        quantity={quantity}
        setQuantity={setQuantity}
      />

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <button
          type="button"
          onClick={handleAddToCart}
          className="flex h-12 items-center justify-center gap-3 rounded-lg bg-[#21150c] px-5 text-sm font-medium text-white transition hover:bg-[#3b2616]"
        >
          <span className="text-lg">🛒</span>
          {added ? "Added to Cart" : "Add to Cart"}
        </button>

        <button
          type="button"
          className="h-12 rounded-lg bg-[#d9a452] px-5 text-sm font-semibold text-stone-950 transition hover:bg-[#c99445]"
        >
          Buy Now
        </button>
      </div>

      <div className="flex flex-wrap items-center justify-end gap-4 border-t border-stone-100 pt-4">
        <button
          type="button"
          className="flex items-center gap-2 text-sm text-stone-700 transition hover:text-[#9b681f]"
        >
          <span className="text-lg">⌯</span>
          Share
        </button>
      </div>
    </div>
  );
};

export default ProductActions;