import React from "react";

const features = [
  {
    icon: "♢",
    text: "Premium quality brass",
  },
  {
    icon: "♢",
    text: "Perfect for daily pooja",
  },
  {
    icon: "♢",
    text: "Included all essential items",
  },
  {
    icon: "♢",
    text: "Beautifully packaged",
  },
];

const ProductFeatures = () => {
  return (
    <ul className="space-y-3">
      {features.map((feature) => (
        <li
          key={feature.text}
          className="flex items-center gap-3 text-sm text-stone-700"
        >
          <span className="text-[#b77a27]">{feature.icon}</span>
          <span>{feature.text}</span>
        </li>
      ))}
    </ul>
  );
};

export default ProductFeatures;