import React, { useMemo } from "react";
import RelatedProductCard from "./RelatedProductCard";

const RelatedProducts = () => {
  const images = useMemo(() => {
    const modules = import.meta.glob(
      "../../assets/productimg/*.{png,jpg,jpeg,webp,avif}",
      {
        eager: true,
        query: "?url",
        import: "default",
      }
    );

    return Object.values(modules);
  }, []);

  const fallbackImages = [
    "https://images.unsplash.com/photo-1604608672516-f1b9c4b0b9b3?auto=format&fit=crop&w=700&q=80",
    "https://images.unsplash.com/photo-1590736969955-71cc94901144?auto=format&fit=crop&w=700&q=80",
    "https://images.unsplash.com/photo-1545231027-637d2f6210f8?auto=format&fit=crop&w=700&q=80",
  ];

  const productImages = images.length ? images : fallbackImages;

  const products = [
    {
      name: "Pooja Thali Set (Medium)",
      price: "₹1,199",
      rating: "4.7",
    },
    {
      name: "Sandalwood Incense Sticks",
      price: "₹299",
      rating: "4.6",
    },
    {
      name: "Brass Lotus Diya (Set of 2)",
      price: "₹899",
      rating: "4.8",
    },
  ].map((product, index) => ({
    ...product,
    image: productImages[index % productImages.length],
  }));

  return (
    <section className="mt-10">
      <div className="mb-5 flex items-center justify-between gap-4">
        <h2 className="font-serif text-2xl text-stone-950">
          You May Also Like
        </h2>

        <div className="flex items-center gap-3">
          <button
            type="button"
            className="hidden text-sm text-stone-700 sm:block"
          >
            View All
          </button>

          <button
            type="button"
            className="flex h-9 w-9 items-center justify-center rounded-md border border-stone-200"
          >
            ‹
          </button>

          <button
            type="button"
            className="flex h-9 w-9 items-center justify-center rounded-md border border-stone-200"
          >
            ›
          </button>
        </div>
      </div>

      <div className="flex gap-4 overflow-x-auto pb-3">
        {products.map((product) => (
          <RelatedProductCard
            key={product.name}
            product={product}
          />
        ))}
      </div>
    </section>
  );
};

export default RelatedProducts;