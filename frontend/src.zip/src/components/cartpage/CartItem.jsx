import { useCart } from '../../context/CartContext'
import { formatCurrency } from '../../utils/formatCurrency'
import QuantitySelector from './QuantitySelector'
function CartItem({ item }) {
  const { increaseQuantity, decreaseQuantity, removeFromCart } = useCart()
  const { product, quantity } = item
  const lineTotal = product.price * quantity
  return (
    <div className="grid grid-cols-[1fr_auto] gap-4 border-b border-brown/8 py-6 last:border-b-0 md:grid-cols-[1fr_100px_120px_100px_auto] md:items-center md:gap-6">
      {/* Product info */}
      <div className="col-span-2 flex gap-4 md:col-span-1">
        <div className="h-20 w-20 shrink-0 overflow-hidden rounded-lg border border-brown/8 bg-cream-card md:h-[88px] md:w-[88px]">
          <img
            src={product.image}
            alt={product.name}
            className="h-full w-full object-contain p-2"
          />
        </div>
        <div className="flex flex-col justify-center">
          <h3 className="font-serif text-[15px] font-medium leading-snug text-brown md:text-base">
            {product.name}
          </h3>
          <p className="mt-0.5 text-xs text-brown-muted md:text-sm">{product.subtitle}</p>
          {product.inStock && (
            <p className="mt-1.5 flex items-center gap-1 text-xs text-sage-dark">
              <svg className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
              </svg>
              In stock
            </p>
          )}
          {/* Mobile price */}
          <p className="mt-2 text-sm font-semibold text-brown md:hidden">
            {formatCurrency(product.price)}
          </p>
        </div>
      </div>
      {/* Desktop price */}
      <p className="hidden text-sm font-semibold text-brown md:block">
        {formatCurrency(product.price)}
      </p>
      {/* Quantity */}
      <div className="flex items-center md:justify-center">
        <QuantitySelector
          quantity={quantity}
          onIncrease={() => increaseQuantity(product.id)}
          onDecrease={() => decreaseQuantity(product.id)}
        />
      </div>
      {/* Line total + remove */}
      <div className="flex items-center justify-end gap-4 md:justify-between">
        <p className="text-sm font-semibold text-brown">{formatCurrency(lineTotal)}</p>
        <button
          type="button"
          onClick={() => removeFromCart(product.id)}
          className="text-brown-muted/60 transition-colors duration-200 hover:text-red-700/70"
          aria-label={`Remove ${product.name} from cart`}
        >
          <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
          </svg>
        </button>
      </div>
    </div>
  )
}
export default CartItem