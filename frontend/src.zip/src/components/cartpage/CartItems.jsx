import { Link } from 'react-router-dom'
import { useCart } from '../../context/CartContext'
import CartItem from './CartItem'
function CartItems() {
  const { cartItems } = useCart()
  return (
    <div>
      {/* Table headers — desktop only */}
      <div className="hidden border-b border-brown/8 pb-3 md:grid md:grid-cols-[1fr_100px_120px_100px_auto] md:gap-6">
        <span className="text-[11px] font-semibold uppercase tracking-[0.1em] text-brown-muted/60">
          Product
        </span>
        <span className="text-[11px] font-semibold uppercase tracking-[0.1em] text-brown-muted/60">
          Price
        </span>
        <span className="text-center text-[11px] font-semibold uppercase tracking-[0.1em] text-brown-muted/60">
          Quantity
        </span>
        <span className="text-[11px] font-semibold uppercase tracking-[0.1em] text-brown-muted/60">
          Total
        </span>
        <span className="w-4" />
      </div>
      <div>
        {cartItems.map((item) => (
          <CartItem key={item.product.id} item={item} />
        ))}
      </div>
      <div className="mt-6 border-t border-brown/8 pt-6">
        <Link
          to="/"
          className="btn-outline inline-flex items-center gap-2 text-sm"
        >
          <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" />
          </svg>
          Continue Shopping
        </Link>
      </div>
    </div>
  )
}
export default CartItems