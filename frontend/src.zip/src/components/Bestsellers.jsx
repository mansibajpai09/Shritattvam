import product1 from '../assets/placeholders/product-1.svg'
import product2 from '../assets/placeholders/product-2.svg'
import product3 from '../assets/placeholders/product-3.svg'
import product4 from '../assets/placeholders/product-4.svg'

const products = [
  { id: 1, name: 'Divine Pooja Kit (Small)', price: '₹1,499', image: product1 },
  { id: 2, name: 'Sandalwood Incense', price: '₹349', image: product2 },
  { id: 3, name: 'Brass Lotus Diya', price: '₹899', image: product3 },
  { id: 4, name: 'Herbal Dhoop Sticks', price: '₹299', image: product4 },
]

function ProductCard({ product }) {
  return (
    <article className="group shrink-0 w-[220px] md:w-auto">
      <a
        href={
          product.id === 1
            ? "/product-details"
            : `/product-${product.id}`
        }
        className="block"
      >
        <div className="relative overflow-hidden rounded-lg bg-cream-card shadow-card transition-all duration-300 group-hover:-translate-y-1 group-hover:shadow-card-hover">
          <div className="aspect-square overflow-hidden p-4">
            <img
              src={product.image}
              alt={product.name}
              className="h-full w-full object-contain transition-transform duration-500 group-hover:scale-105"
            />
          </div>
        </div>

        <div className="mt-3 px-1">
          <h3 className="font-serif text-[15px] leading-snug text-brown transition-colors duration-300 group-hover:text-gold-dark">
            {product.name}
          </h3>

          <p className="mt-1 text-sm font-semibold text-brown">
            {product.price}
          </p>
        </div>
      </a>
    </article>
  )
}

function Bestsellers() {
  return (
    <section className="py-16 md:py-20" id="bestsellers">
      <div className="section-container">
        <div className="mb-8 flex items-center justify-between">
          <h2 className="section-heading">BestSellers</h2>

          <a href="#all-products" className="view-all-link">
            View All
          </a>
        </div>

        <div className="flex gap-5 overflow-x-auto pb-2 scrollbar-hide md:grid md:grid-cols-4 md:overflow-visible md:gap-6">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
            />
          ))}
        </div>
      </div>
    </section>
  )
}

export default Bestsellers