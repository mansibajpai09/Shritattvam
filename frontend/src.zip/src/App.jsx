import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Home from './pages/home'
import { CartProvider } from './context/CartContext'
import ProductDetails from "./pages/productDetails";
import Cart from './pages/Cart'
import Checkout from './pages/Checkout'
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/product-details" element={<ProductDetails />} />
      </Routes>
    </BrowserRouter>
      <CartProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/checkout" element={<Checkout />} />
        </Routes>
      </BrowserRouter>
    </CartProvider>
  )
}
export default App