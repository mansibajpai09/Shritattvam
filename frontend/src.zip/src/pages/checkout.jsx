import { Link } from 'react-router-dom'
import Navbar from '../components/Navbar'
function Checkout() {
  return (
    <div className="min-h-screen bg-cream-light">
      <Navbar />
      <main className="section-container flex flex-col items-center py-16 text-center md:py-24">
        <h1 className="font-serif text-3xl font-medium text-brown">Checkout</h1>
        <p className="mt-4 max-w-md text-sm leading-relaxed text-brown-muted">
          Checkout is coming soon. Your cart has been saved and is ready when you return.
        </p>
        <Link to="/cart" className="btn-primary mt-8">
          Back to Cart
        </Link>
      </main>
    </div>
  )
}
export default Checkout