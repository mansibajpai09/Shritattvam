import Navbar from '../components/Navbar'
import CartBreadcrumb from '../components/cart/CartBreadcrumb'
import CartHeader from '../components/cart/CartHeader'
import FreeShippingProgress from '../components/cart/FreeShippingProgress'
import CartItems from '../components/cart/CartItems'
import OrderSummary from '../components/cart/OrderSummary'
import EmptyCart from '../components/cart/EmptyCart'
import CartTrustFeatures from '../components/cart/CartTrustFeatures'
import { useCart } from '../context/CartContext'
function Cart() {
  const { cartItems } = useCart()
  const isEmpty = cartItems.length === 0
  return (
    <div className="min-h-screen bg-cream-light">
      <Navbar />
      <main className="section-container py-8 md:py-12">
        <CartBreadcrumb />
        {isEmpty ? (
          <EmptyCart />
        ) : (
          <>
            <CartHeader />
            <div className="grid grid-cols-1 gap-10 lg:grid-cols-[1fr_380px] lg:gap-12 xl:grid-cols-[1fr_400px]">
              <div>
                <FreeShippingProgress />
                <CartItems />
              </div>
              <div className="lg:sticky lg:top-[100px] lg:self-start">
                <OrderSummary />
              </div>
            </div>
          </>
        )}
      </main>
      {!isEmpty && <CartTrustFeatures />}
    </div>
  )
}
export default Cart
