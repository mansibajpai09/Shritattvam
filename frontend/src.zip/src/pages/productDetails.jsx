import React from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

import Breadcrumb from "../components/Productpage/Breadcrumb";
import ProductGallery from "../components/Productpage/ProductGallery";
import ProductInfo from "../components/Productpage/ProductInfo";
import ServiceHighlights from "../components/Productpage/ServiceHighlights";
import ProductTabs from "../components/Productpage/ProductTabs";
import RelatedProducts from "../components/Productpage/RelatedProducts";
import TrustBanner from "../components/Productpage/TrustBanner";

const ProductDetails = () => {
  return (
    <div className="min-h-screen bg-[#fcfaf7] text-stone-900">
      <Navbar />

      <main>
        <div className="mx-auto max-w-[1440px] px-5 py-6 sm:px-8 lg:px-11">
          <Breadcrumb />

          <section className="grid gap-10 lg:grid-cols-[1.25fr_0.9fr] lg:gap-12 xl:gap-16">
            <ProductGallery />

            <ProductInfo />
          </section>

          <div className="mt-8">
            <ServiceHighlights />
          </div>

          <ProductTabs />

          <RelatedProducts />

          <TrustBanner />
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default ProductDetails;